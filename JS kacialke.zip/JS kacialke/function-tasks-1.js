console.groupCollapsed('1. Parašykite funkciją, kuri grąžina pirmą masyvo elementą.');
{
  const portfolio = ['MSFT', 'BABA', 'APPL', 'AMZN', 'GOOGL', 'SPG', 'T', 'O'];
  function firstE(portfolio) {
    return portfolio[0];
  }
  const firstPos = firstE(portfolio)
  console.log(firstPos)
}
console.groupEnd();


console.groupCollapsed('2. Parašykite funkciją, kuri pašalina pirmą masyvo elementą ir jį grąžina.');

{
  const portfolio = ['MSFT', 'BABA', 'APPL', 'AMZN', 'GOOGL', 'SPG', 'T', 'O'];
  function remFirstArrEl(portfolio) {
    return portfolio.shift();
  }
  const sellF = remFirstArrEl(portfolio)
  console.log(sellF)
  console.log(portfolio)

}
console.groupEnd();

console.groupCollapsed('3.Parašykite funkciją, kuri grąžina paskutinį masyvo elementą');
{
  const portfolio = ['MSFT', 'BABA', 'APPL', 'AMZN', 'GOOGL', 'SPG', 'T'];
  function lastE(portfolio) {
    return portfolio[portfolio.length - 1];
  }
  const lastP = lastE(portfolio)
  console.log(lastP)
}

console.groupEnd();


console.groupCollapsed('4.Parašykite funkciją, kuri pašalina paskutinį masyvo elementą ir jį grąžina.');
{
  const portfolio = ['MSFT', 'BABA', 'APPL', 'AMZN', 'GOOGL', 'SPG', 'T', 'O'];
  function retLast(portfolio) {
    return portfolio.pop();
  }
  const sellL = retLast(portfolio);
  console.log(sellL)
  console.log(portfolio)
}
console.groupEnd();

console.groupCollapsed('5.Parašykite funkciją, kuri grąžina elementų kiekį masyve')

const portfolio = ['MSFT', 'BABA', 'APPL', 'AMZN', 'GOOGL', 'SPG', 'T', 'O', 'SPOT', 'NNN', 'STAG', 'WPC', 'IGN', 'SRC', 'STOR', 'VICI'];
function calcPositions(portfolio) {
  return portfolio.length;
}
const howManyP = calcPositions(portfolio);
console.log(howManyP)

console.groupEnd();

console.groupCollapsed('6. Parašykite funkciją, kuri atspausdina paskutinio masyvo elemento indeksą')
{
  const portfolio = ['MSFT', 'BABA', 'APPL', 'AMZN', 'GOOGL', 'SPG', 'T', 'O', 'SPOT', 'NNN', 'STAG', 'WPC', 'IGN', 'SRC', 'STOR', 'VICI'];

  function lastItemIndex(portfolio) {

     return portfolio.length - 1
  }
  console.log(lastItemIndex(portfolio))
}
console.groupEnd();

console.groupCollapsed('7.Parašykite funkciją, kuri atspausdina kiekvieno masyvo elemento indeksus eilutėmis')
{
  const portfolioP = ['MSFT', 'BABA', 'APPL', 'AMZN', 'GOOGL', 'SPG', 'T'];

  function inDiffLines(portfolioP) {
    for (let i = 0; i < portfolioP.length; i++) {
      console.log(portfolioP.indexOf(portfolioP[i]));
    }
  }
  inDiffLines(portfolioP)
}
console.groupEnd();

console.groupCollapsed('8. Parašykite funkciją, kuri atspausdina kiekvieno masyvo elemento reikšmes eilutėmis');
{
  const portfolioP = ['MSFT', 'BABA', 'APPL', 'AMZN', 'GOOGL', 'SPG', 'T'];

  function inDiffLinesItems(portfolioP) {
    for (let i = 0; i < portfolioP.length; i++) {
      console.log(portfolioP[i]);
    }
  }
  inDiffLinesItems(portfolioP)
}
console.groupEnd();

console.groupCollapsed('9. Parašykite funkciją, kuri atspausdina kiekvieno masyvo elemento indekso ir reikšmių poras eilutėmis, tokiu formatu:  ');
// [0] => reikšmė
// [1] => reikšmė
// [2] => reikšmė
{
  const portfolio = ['MSFT', 'BABA', 'APPL', 'AMZN', 'GOOGL', 'SPG', 'T', 'O', 'SPOT', 'NNN', 'STAG', 'WPC', 'IGN', 'SRC', 'STOR', 'VICI', 'IGNITIS'];
  function indexAndValue(portfolio){
     for(let i = 0; i < portfolio.length; i++){
      console.log(`[${i}] => ${portfolio[i]}`);
     }
   }
   indexAndValue(portfolio);
}
console.groupEnd();

console.groupCollapsed('10. Parašykite funkciją, kuri atspausdina masyvo elementus atbuline tvarka eilutėmis, iš galo.');
{
  const portfolio = ['MSFT', 'BABA', 'APPL', 'AMZN', 'GOOGL', 'SPG', 'T', 'O', 'SPOT', 'NNN', 'STAG', 'WPC', 'IGN', 'SRC', 'STOR', 'VICI', 'IGNITIS'];

  function revPortfolio (portfolio) {
    for(let i = portfolio.length - 1; i >= 0; i--){
      console.log(portfolio[i]);
    }
  }
  revPortfolio(portfolio);
}
console.groupEnd();


  console.groupCollapsed('11. Parašykite funkciją, kuri atspausdina kiekvieno masyvo elemento indeksus vienoje eilutėje: 0 1 2 3 ...');
{
  const portfolio = ['MSFT', 'BABA', 'APPL', 'AMZN', 'GOOGL', 'SPG', 'T', 'O', 'SPOT', 'NNN', 'STAG', 'WPC', 'IGN', 'SRC', 'STOR', 'VICI', 'IGNITIS'];
  let line = [];
  function IndexInOneLine(portfolio) {
    for (let i = 0; i < portfolio.length; i++) {
      line.push(i);
    }
    console.log(line.join(' '));
  }
  IndexInOneLine(portfolio);
}
console.groupEnd();


console.groupCollapsed('12. Parašykite funkciją, kuri atspausdina kiekvieno masyvo elemento reikšmes vienoje eilutėje');

{
  const portfolio = ['MSFT', 'BABA', 'APPL', 'AMZN', 'GOOGL', 'SPG', 'T', 'O', 'SPOT', 'NNN', 'STAG', 'WPC', 'IGN', 'SRC', 'STOR', 'VICI', 'IGNITIS'];
  function InSingleLine(portfolio) {
    console.log(portfolio.join(' '));
  }
  InSingleLine(portfolio);
}
console.groupEnd();

console.groupCollapsed(
  '13. Parašykite funkciją, kuri atspausdina kiekvieno masyvo elemento indekso ir reikšmių poras vienoje eilutėje, tokiu formatu:');
  //  [0]=>17 [1]=>8 [2]=>88 ...
  {
  
    function pairsInLine(portfolio) {
      const result = [];
      for (let i = 0; i < portfolio.length; i++) {
        result.push(`[${i}]=>${portfolio[i]}`);
      }
      console.log(result.join(' '));
    }
    pairsInLine(['MSFT', 'BABA', 'APPL', 'AMZN', 'GOOGL', 'SPG', 'T', 'O', 'SPOT', 'NNN', 'STAG', 'WPC', 'IGN', 'SRC', 'STOR', 'VICI', 'IGNITIS']);

  }
  console.groupEnd();
/*
console.groupCollapsed('Kartojimas');

{
  const portfolio = ['MSFT', 'BABA', 'APPL', 'AMZN', 'GOOGL', 'SPG', 'T', 'O', 'SPOT', 'NNN', 'STAG', 'WPC', 'IGN', 'SRC', 'STOR', 'VICI', 'IGNITIS'];
 
console.groupEnd();
*/
