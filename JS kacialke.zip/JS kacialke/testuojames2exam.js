
const data = [
    {
      name: "Agnė",
      surname: "Lazdauskienė",
      age: 19,
      height: 180,
      weight: 97,
      sex: "female",
    },
    {
      name: "Lina",
      surname: "Gerutytė",
      age: 23,
      height: 168,
      weight: 67,
      sex: "female",
    },
    {
      name: "Mindaugas",
      surname: "Vilkgaudis",
      age: 54,
      height: 190,
      weight: 65,
      sex: "male",
    },
    {
      name: "Vytautas",
      surname: "Gudrauskas",
      age: 45,
      height: 187,
      weight: 80,
      sex: "male",
    },
    {
      name: "Lapė",
      surname: "Gerdutytė",
      age: 66,
      height: 157,
      weight: 80,
      sex: "female",
    },
    {
      name: "Bronė",
      surname: "Jankauskienė",
      age: 55,
      height: 186,
      weight: 78,
      sex: "female",
    },
    {
      name: "Jolanta",
      surname: "Giedraitytė",
      age: 15,
      height: 149,
      weight: 80,
      sex: "female",
    },
    {
      name: "Modestas",
      surname: "Margelis",
      age: 35,
      height: 167,
      weight: 89,
      sex: "male",
    },
  ];
  console.groupCollapsed('------------------------------------ 1 Dalis ------------------------------------');
  const calcBMI = (weight, heightCM) => Math.round(10 * weight / (heightCM / 100) ** 2) / 10;

// 1. Sukurti objektų(žmonių) masyvą su 8 elementais, kuriame būtų:
//   - name
//   - surname
//   - age
//   - height
//   - weight
//   - sex

// class people {
//     constructor (name, surname, age, height, weight, sex){
//         this.name = name;
//         this.surname = surname;
//         this.age = age;
//         this.height = height;
//         this.weight = weight;
//         this.sex = sex;
//     }
// }
// const naujokas = new people ('Linas', 'Urba', 42, 198, 96, 'male')
// console.log(naujokas)




('2. Panaudojant Array.prototype.forEach:');
  {
    console.group('Atspausdinti kiekvieną elementą');
    {
      data.forEach(person => console.log(person));
          
    }
}
    console.groupEnd();

    console.group('Atspausdinti kiekvieno elemento pilną vardą');
    {
    
      data.forEach(({name, surname}) => console.log(`${name} ${surname}`));
    }
    
    console.group('Atspausdinti kiekvieno elemento kūno masės indeksą');
    {
      data.forEach(({ weight, height }) => console.log(calcBMI(weight, height)));
    }
    console.groupEnd();
 
    ('3. Panaudojant Array.filter atrinkti į naują masyvą ir po to atspausdinti žmones:');
  {
    console.group('kurių vardas ilgesnis nei 6 simboliai');
    {
        const peopleWithLongNames = data.filter(p => p.name.length > 6);
        console.log(peopleWithLongNames)
    console.groupEnd();
}}
    
    console.group('kurių svoris didesnis nei 80kg');

    const bigPeople = data.filter(p => p.weight > 80);
    console.log(bigPeople)

    console.group('kurie aukštesni nei 185cm');
    {
      const tallPeople = data.filter(p => p.height > 185)
      console.log(tallPeople)
    }
    console.groupEnd();
    
    console.groupCollapsed('4. Panaudojant Array.prototype.map atrinkti į naują masyvą ir po to atspausdinti');
  {
    console.group('ūgius');
    {
     console.log(data.map(p => p.height));
    }
    console.groupEnd();
    console.group('svorius');
    {
     console.table(data.map(p => p.weight));
    }
    console.groupEnd();
    console.group('ūgius, svorius ir amžius');
    {
      console.table(data.map(({height, weight, age}) => ({height, weight, age})));

    }
    console.groupEnd();
}

console.group('KMI indeksus');
    {
      console.log(data.map(({ weight, height }) => calcBMI(weight, height)));
    }
    console.groupEnd();
    console.group('KMI indeksus ir amžius');
    {
      console.log(data.map(({ weight, height, age }) => ({
        age,
        bmi: calcBMI(weight, height)
      })));
    }
    console.groupEnd();

    console.groupCollapsed('5. Panaudojant Array.reduce suskaičiuoti ir po to atspausdinti');
  {
    console.group('svorių vidurkį');
    {
      console.log(data.reduce((sum, p) => sum + p.weight, 0) / data.length);
    }
    console.groupEnd();
    console.group('ūgių vidurkį');
    {
      console.log(data.reduce((sum, p) => sum + p.height, 0) / data.length);

}
console.groupEnd();
}
console.groupEnd();
console.groupEnd();

console.groupCollapsed('------------------------------------ 2 Dalis ------------------------------------');
{
  class Person {
    name;
    surname;
    height;
    weight;
    sex;
    age;

    constructor({ name, surname, height, weight, sex, age }) {
      this.name = name;
      this.surname = surname;
      this.height = height;
      this.weight = weight;
      this.sex = sex;
      this.age = age;
    }

    get bmi() {
      return Math.round(10 * this.weight / (this.height / 100) ** 2) / 10;
    }

    getBMI = () => {
      return Math.round(10 * this.weight / (this.height / 100) ** 2) / 10;
    }

  }

  const peopleArr = data.map(p => new Person(p));

  console.group('0. Pasinaudojant 1 dalies asmens apibūdinimu, sukurti Person klasę, kuri apipavidalina tokio tipo objektą');
  {
    console.table(peopleArr);
    peopleArr.forEach(p => console.log(p.getBMI()));
    // peopleArr.forEach(p => console.log(p.bmi));
    peopleArr.forEach(p => console.log(p.toString()));
    // peopleArr.forEach(p => console.log(p.string));
  }
  console.groupEnd();

  console.group('1. Atrinkti moteris, kuriuos jaunesnės nei 20 metų ir svoris didesnis nei 70kg ');
  {
    const result = peopleArr.filter(p => p.sex === 'female' && p.age < 20 && p.weight > 70);
    console.table(result);
  }
  console.groupEnd();

  console.group('2. Atrinkti vyrus, kurie vyresni nei 25 metai ir KMI mažesnis nei 18,5');
  {
    const result = peopleArr.filter(p => p.sex === 'male' && p.age > 25 && p.getBMI() < 18.5);
    console.table(result);
  }
  console.groupEnd();

  console.group('3. Atrinkti vaikus, su antsvoriu (KMI > 30)');
  {
    const result = peopleArr.filter(p => p.age < 18 && p.getBMI() > 30);
    console.table(result);
  }
  console.groupEnd();

  console.group('4. Atrinkti pensininkus, su antsvoriu (KMI > 30)');
  {
    const result = peopleArr.filter(p => p.age >= 65 && p.getBMI() > 30);
    console.table(result);
  }
  console.groupEnd();

  console.group('5. Atrinkti visus, kieno KMI nepatenka į rėžius [18.5; 25]');
  {
    const result = peopleArr.filter(p => {
      const bmi = p.getBMI();
      return bmi < 18.5 || bmi > 25;
    });
    console.table(result);
  }
  console.groupEnd();
}
console.groupEnd();
